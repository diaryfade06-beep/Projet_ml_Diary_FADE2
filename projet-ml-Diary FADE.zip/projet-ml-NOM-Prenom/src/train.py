"""Entraînement : compare 2 modèles, choisit le meilleur, l'enregistre dans models/model.joblib."""
from pathlib import Path

import joblib
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, confusion_matrix, f1_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data" / "flux_train.csv"
MODEL = ROOT / "models" / "model.joblib"

NUM = ["duration", "dst_port", "src_bytes", "dst_bytes", "nb_packets",
       "nb_failed_logins", "nb_conn_same_host", "syn_rate"]
CAT = ["protocol"]


def build_pipeline(clf):
    pre = ColumnTransformer([
        ("num", Pipeline([("imp", SimpleImputer(strategy="median")),
                          ("sc", StandardScaler())]), NUM),
        ("cat", OneHotEncoder(handle_unknown="ignore"), CAT),
    ])
    return Pipeline([("pre", pre), ("clf", clf)])


def main():
    df = pd.read_csv(DATA)
    print("Taille :", df.shape)
    print("Valeurs manquantes :\n", df.isna().sum()[df.isna().sum() > 0])
    print("Répartition attaque :\n", df["attaque"].value_counts(normalize=True).round(3))

    X, y = df.drop(columns="attaque"), df["attaque"]
    X_tr, X_val, y_tr, y_val = train_test_split(
        X, y, test_size=0.25, stratify=y, random_state=42)

    candidats = {
        "Régression logistique": LogisticRegression(max_iter=1000, class_weight="balanced"),
        "Forêt aléatoire": RandomForestClassifier(
            n_estimators=300, class_weight="balanced", random_state=42, n_jobs=-1),
    }

    scores = {}
    for nom, clf in candidats.items():
        pipe = build_pipeline(clf).fit(X_tr, y_tr)
        pred = pipe.predict(X_val)
        scores[nom] = f1_score(y_val, pred)
        print(f"\n===== {nom} =====")
        print(classification_report(y_val, pred, target_names=["normal", "attaque"]))
        print("Matrice de confusion [[VN FP] [FN VP]] :\n", confusion_matrix(y_val, pred))

    meilleur = max(scores, key=scores.get)
    print(f"\nMeilleur modèle : {meilleur} (F1 attaque = {scores[meilleur]:.3f})")

    final = build_pipeline(candidats[meilleur]).fit(X, y)  # ré-entraîné sur toutes les données
    MODEL.parent.mkdir(exist_ok=True)
    joblib.dump(final, MODEL)
    print("Modèle enregistré :", MODEL)


if __name__ == "__main__":
    main()
