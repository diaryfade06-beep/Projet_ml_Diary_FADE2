"""Prédiction : charge models/model.joblib (Pipeline complet) et prédit 0/1."""
from pathlib import Path

import joblib
import pandas as pd

MODEL_PATH = Path(__file__).resolve().parent.parent / "models" / "model.joblib"
_model = None


def predict(df: pd.DataFrame) -> list:
    global _model
    if _model is None:
        _model = joblib.load(MODEL_PATH)
    return [int(p) for p in _model.predict(df)]


if __name__ == "__main__":
    data = pd.read_csv(Path(__file__).resolve().parent.parent / "data" / "flux_train.csv")
    print(predict(data.drop(columns="attaque").head(10)))
