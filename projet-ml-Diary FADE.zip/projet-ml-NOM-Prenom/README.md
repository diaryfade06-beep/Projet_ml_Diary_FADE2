# Projet 2 — Détecter des attaques réseau avec le Machine Learning

## Utilisation
```bash
pip install -r requirements.txt
python src/train.py     # entraîne, compare les modèles, enregistre models/model.joblib
python src/predict.py   # petit test de la fonction predict
```

## Résultats

**Nom / Prénom :** NOM Prénom  <!-- à remplacer -->

Évaluation sur un jeu de validation (25 % des données, stratifié, `random_state=42`, 750 flux dont 208 attaques).

| Modèle | F1 (attaque) | Rappel (attaque) | Précision (attaque) |
|---|---|---|---|
| Régression logistique | 0,92 | 0,90 | 0,94 |
| Forêt aléatoire | 0,97 | 0,97 | 0,98 |

**Prétraitement (Pipeline)** : imputation de `duration` par la médiane (90 valeurs manquantes), standardisation des variables numériques, one-hot encoding de `protocol`. `class_weight="balanced"` compense le déséquilibre (≈ 28 % d'attaques).

**Modèle retenu et pourquoi :** la forêt aléatoire, meilleur F1 sur la classe « attaque » (0,97 contre 0,92). Elle capte des relations non linéaires entre variables (ex. `syn_rate` élevé combiné à `nb_conn_same_host` élevé pour un scan, `nb_failed_logins` pour la force brute) qu'un modèle linéaire modélise mal. Elle a ensuite été ré-entraînée sur les 3000 flux et enregistrée dans `models/model.joblib`.

**Analyse des erreurs :**

Matrice de confusion de la forêt aléatoire (validation) :

| | Prédit normal | Prédit attaque |
|---|---|---|
| Réel normal | 537 | 5 (faux positifs) |
| Réel attaque | 6 (faux négatifs) | 202 |

- **6 attaques ratées** sur 208 (contre 21 pour la régression logistique). Les faux négatifs sont le pire cas en sécurité : une attaque non détectée passe sous le radar, l'intrus agit sans alerte (compromission, déni de service, vol de données).
- **5 faux positifs** : de fausses alertes qui fatiguent les analystes, mais leur coût reste bien inférieur à celui d'une attaque non détectée. On privilégie donc un rappel élevé.
